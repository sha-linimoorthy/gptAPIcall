from flask import Blueprint, jsonify,request
from chatGPT.GPT_service import ChatGptService
from chatGPT.model import MessageRequestDTO
gpt_route_path = 'chat-gpt-ai'
gpt_route = Blueprint(gpt_route_path, __name__)

@gpt_route.route('/message',methods=['POST'])
def get_ai_model_answer():
    body = request.json
    return jsonify({
        'result': ChatGptService.gpt_service_response(
            MessageRequestDTO.new_instance_from_flask_body(body)
        )
    })


@gpt_route.route('/model')
def get_models():
    return jsonify({
        "models": ChatGptService.list_models()
    })