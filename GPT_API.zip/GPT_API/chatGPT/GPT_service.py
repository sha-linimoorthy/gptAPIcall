from openai import OpenAI
import os
from chatGPT.model import MessageRequestDTO

OpenAI.api_key=os.getenv('OPENAI_API_KEY')
OpenAI.organization=os.getenv('ORG_ID')
client=OpenAI()
class ChatGptService:
    @classmethod
    def gpt_service_response(cls,data:MessageRequestDTO):
        return client.completions.create(
            prompt=data.question,
            model=data.model_id,
            temperature=data.temperature,
            max_tokens=data.max_tokens
        )

    @classmethod
    def list_models(cls):
        return openai.Model.list()