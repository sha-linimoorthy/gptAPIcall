from flask import Flask
from chatGPT.GPT_controller import gpt_route_path, gpt_route

def bootstrap():
    app=Flask(__name__)
    app.register_blueprint(gpt_route,url_prefix=f'/{gpt_route_path}')
    app.run(port=3000,debug=True)


if __name__=='__main__':
    bootstrap()